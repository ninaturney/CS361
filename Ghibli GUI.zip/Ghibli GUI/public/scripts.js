// scripts.js

// Handle button clicks in the navbar
document.getElementById('clipsButton')?.addEventListener('click', function () {
    window.location.href = 'movieClips.html';
});

document.getElementById('reviewsButton')?.addEventListener('click', function () {
    window.location.href = 'movieReviews.html';
});

document.getElementById('libraryButton')?.addEventListener('click', function (event) {
    window.location.href = 'library.html';
});

// Handle "Logout" button click
document.getElementById('logoutButton')?.addEventListener('click', function () {
    document.getElementById('logoutPopup').style.display = 'flex';
});

// Handle "No" button in the popup
document.getElementById('logoutNoBtn')?.addEventListener('click', function () {
    document.getElementById('logoutPopup').style.display = 'none';
});

// Handle "Yes" button in the popup
document.getElementById('logoutYesBtn')?.addEventListener('click', function () {
    document.getElementById('logoutPopup').style.display = 'none';
    window.location.href = 'index.html';
});

